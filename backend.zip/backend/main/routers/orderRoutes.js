const express = require("express");
const router = express.Router();
const orderController = require("../controllers/orderController");
const isAuth = require("../middleware/isAuth");
const isAdmin = require("../middleware/isAdmin");

router.post("/", isAuth, orderController.createOrder);
router.get("/", isAuth, isAdmin, orderController.getOrders);
module.exports = router;
