import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function ProfileDetails(props) {
  const [disabled, setDisabled] = useState(true)
  const [formData, setFormData] = useState({
    name: '',
    lastName: '',
    email: '',
  })
  const [boutiqueData, setBoutiqueData] = useState(null)

  const userData = JSON.parse(localStorage.getItem('userData'))
  const userId = userData ? userData._id : null

  const [refresh, setRefresh] = useState(0)

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const response = await axios.put(
        `http://localhost:3000/user/updateUser/${userId}`,
        formData,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        },
      )
      console.log('User updated successfully:', response.data)
      fetchUser(userId)
    } catch (error) {
      console.error('Registration failed:', error)
    }
  }

  console.log(userId)

  async function fetchUser(userId) {
    try {
      const response = await axios.get(
        `http://localhost:3000/user/getUser/${userId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      localStorage.setItem('userData', JSON.stringify(response.data))
      setFormData({
        name: response.data.name,
        lastName: response.data.lastName,
        email: response.data.email,
      })

      if (response.data.boutiqueId) {
        fetchBoutiqueDetails(response.data.boutiqueId)
      }
    } catch (error) {
      console.error('Error fetching user:', error)
    }
  }

  async function fetchBoutiqueDetails(boutiqueId) {
    try {
      const response = await axios.get(
        `http://localhost:3000/userRole/getBoutique/${boutiqueId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      setBoutiqueData(response.data)
    } catch (error) {
      console.error('Error fetching boutique details:', error)
    }
  }
  useEffect(() => {
    if (userId) {
      fetchUser(userId)
    }
  }, [userId, refresh])

  return (
    <div>
      <h1 className='text-3xl font-bold'>Profile</h1>
      <div className='flex flex-col mt-8'>
        <div className='grid grid-cols-2 gap-8'>
          <div className='flex flex-col'>
            <label>Nom</label>
            <input
              name='name'
              value={formData.name}
              onChange={handleInputChange}
              className='border-2 mt-2 h-10 px-4'
              placeholder={props.value ? props.value.name : ''}
              disabled={disabled}
            />
          </div>
          <div className='flex flex-col'>
            <label>Prenom</label>
            <input
              name='lastName'
              value={formData.lastName}
              onChange={handleInputChange}
              className='border-2 mt-2 h-10 px-4'
              placeholder={props.value ? props.value.lastName : ''}
              disabled={disabled}
            />
          </div>
        </div>
        <div className='flex flex-col mt-4'>
          <label>Email</label>
          <input
            name='email'
            value={formData.email}
            onChange={handleInputChange}
            type='Email'
            className='border-2 mt-2 h-10 px-4'
            placeholder={props.value ? props.value.email : ''}
            disabled={disabled}
          />
        </div>

        <div className='mt-12 '>
          <button
            className='bg-blue-400 w-40 h-10 hover:bg-blue-500'
            onClick={() => setDisabled(false)}
          >
            Editer Profile
          </button>
          {!disabled && (
            <button
              className='bg-gray-600 w-40 h-10 hover:bg-gray-700 text-white ml-8 '
              onClick={handleSubmit}
            >
              Submit
            </button>
          )}
          {boutiqueData && (
            <div>
              <h2 className='text-xl font-bold mt-8'>Boutique Details</h2>
              <p>Boutique Name: {boutiqueData.name}</p>
              <Link
                to='/responsabledashboard'
                className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4'
              >
                Go to Dashboard
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default ProfileDetails
