import React, { useState, useContext, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import logo from '../Assets/logo.webp'
import searchIcon from '../Assets/search-icon.png'
import panelIcon from '../Assets/card.png'
import avatar from '../Assets/avatar.png'
import { UserContext } from '../Usercontext'

function Header() {
  const [showSearchBox, setShowSearchBox] = useState(false)
  const [toggleDropDwn, setToggleDropDwn] = useState(false)
  const { data, setData } = useContext(UserContext)
  const [isUser, setIsUser] = useState(false)
  const [userEmail, setUserEmail] = useState('')
  const [userName, setUserName] = useState('')
  const [userLastname, setUserLastname] = useState('')
  const [userRole, setUserRole] = useState('')
  const [searchText, setSearchText] = useState('') // Add state for search text

  const navigate = useNavigate()

  const toggleSearchBox = () => {
    setShowSearchBox(!showSearchBox)
  }

  useEffect(() => {
    function checkRole() {
      const userDataString = localStorage.getItem('userData')
      if (userDataString) {
        const userData = JSON.parse(userDataString)
        setUserName(userData.name)
        setUserLastname(userData.lastName || '')
        setUserEmail(userData.email)
        setUserRole(userData.role)
        if (userData.role === 'User') {
          setIsUser(true)
        } else {
          setIsUser(false)
        }
      } else {
        console.error('User data not found in local storage')
      }
    }
    checkRole()
  }, [])

  const handleLogout = () => {
    localStorage.removeItem('userData')
    localStorage.removeItem('token')
    localStorage.removeItem('isFirstLogin')
    localStorage.clear()
    setData(null)
    setUserName('')
    setUserLastname('')
    setUserEmail('')
    setUserRole('')
    setIsUser(false)
    navigate('/login')
  }

  const handleDashboardClick = () => {
    if (userRole === 'Admin') {
      navigate('/admin-dashboard')
    } else if (userRole === 'Responsable') {
      navigate('/responsabledashboard')
    } else {
      // User role, no dashboard access
      return
    }
  }
  const handleSearchSubmit = (e) => {
    e.preventDefault()
    navigate(`/products?search=${searchText}`) // Navigate to products page with search query
    setSearchText('') // Clear search text after submission
  }

  return (
    <div className='sticky top-0 bg-white z-10'>
      <div className='shadow'>
        <div className='flex justify-between items-center px-40 h-28'>
          <div className='flex items-center gap-6'>
            <a href='/home'>
              <img className='w-14' src={logo} alt='Logo' />
            </a>
            <a
              href='/home'
              className='hover:underline focus:underline focus:font-normal font-thin sticky px-2 hover:scale-110'
            >
              Home
            </a>
            <a
              href='/'
              className='hover:underline focus:underline focus:font-normal font-thin sticky px-2 hover:scale-110'
            >
              Contact
            </a>
            <a
              href='/stores'
              className='hover:underline focus:underline focus:font-normal font-thin sticky px-2 hover:scale-110'
            >
              Stores
            </a>
            <a
              href='/products'
              className='hover:underline focus:underline focus:font-normal font-thin sticky px-2 hover:scale-110'
            >
              Products
            </a>
          </div>
          <div className='flex gap-3 items-center'>
            <img
              src={searchIcon}
              onClick={toggleSearchBox}
              className='w-8 hover:scale-110 hover:cursor-pointer'
              alt='Search Icon'
            />
            {showSearchBox && (
              <div>
                <form onSubmit={handleSearchSubmit}>
                  <input
                    type='text'
                    placeholder='Search...'
                    className='border border-gray-300 rounded px-2 py-1'
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                  />
                </form>
              </div>
            )}
            <a href='/panier'>
              <img
                src={panelIcon}
                className='w-8 hover:scale-110 hover:cursor-pointer'
                alt='Panel Icon'
              />
            </a>
            <div
              onMouseEnter={() => setToggleDropDwn(!toggleDropDwn)}
              onMouseLeave={() => setToggleDropDwn(!toggleDropDwn)}
            >
              <img
                id='avatarButton'
                type='button'
                data-dropdown-toggle='userDropdown'
                data-dropdown-placement='bottom-start'
                className='w-10 h-10 rounded-full cursor-pointer'
                src={avatar}
                alt='User dropdown'
              />
              {toggleDropDwn && data && (
                <div
                  id='userDropdown'
                  className='z-10 absolute bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700 dark:divide-gray-600'
                >
                  <div className='px-4 py-3 text-sm text-gray-900 dark:text-white'>
                    <div>
                      {userName} {userLastname}
                    </div>
                    <div className='font-medium truncate'>{userEmail}</div>
                  </div>
                  <ul
                    className='py-2 text-sm text-gray-700 dark:text-gray-200'
                    aria-labelledby='avatarButton'
                  >
                    {!isUser && (
                      <li>
                        <button
                          onClick={handleDashboardClick}
                          className='block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white'
                        >
                          Dashboard
                        </button>
                      </li>
                    )}
                    <li>
                      <a
                        href='/profile'
                        className='block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white'
                      >
                        Profile
                      </a>
                    </li>
                  </ul>
                  <div className='py-1'>
                    <button
                      onClick={handleLogout}
                      className='block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white'
                    >
                      Sign out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Header
