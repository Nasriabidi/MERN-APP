import React from 'react';
import QuantityButtonComponent from './QuantityButtonComponent';
import trash from '../Assets/trash.png';

function PanierProduct({ product, quantity, onQuantityChange, onRemoveProduct }) {
  const totalPrice = product.price * quantity;

  const handleIncrement = () => {
    onQuantityChange(product._id, quantity + 1);
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      onQuantityChange(product._id, quantity - 1);
    }
  };

  const handleRemoveProduct = () => {
    onRemoveProduct(product._id);
  };

  return (
    <div className='grid grid-cols-4 mt-8'>
      <div className='col-span-2'>
        <div className='flex gap-12'>
          <div>
            <img src={product.image} className='w-28 h-36' />
          </div>
          <div>
            <h4 className='text-xl font-light'>{product.name}</h4>
            <div className='flex flex-row gap-4 mt-2 text-gray-500'>
              <p>{product.price}</p>
              <p>DT</p>
            </div>
            <h4 className='mt-4 text-sm'>{product.categorie}</h4>
          </div>
        </div>
      </div>
      <div className='grid grid-cols-2 mt-8 gap-8'>
      <div className=''>
          <QuantityButtonComponent
            quantity={quantity}
            onIncrement={handleIncrement}
            onDecrement={handleDecrement}
          />
        </div>
        <div>
          <img className='w-8 cursor-pointer' src={trash} onClick={handleRemoveProduct} />
        </div>
      </div>
      <div className='text-right mt-8'>{totalPrice.toFixed(2)}</div>
    </div>
  )
}

export default PanierProduct
