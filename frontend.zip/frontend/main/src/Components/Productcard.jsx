import React from 'react'
import product from '../Assets/product.jpg'
import { useNavigate } from 'react-router-dom'

export default function Productcard({ product }) {
  const navigate = useNavigate()

  const handleClick = () => {
    navigate(`/singleproduct`, { state: { product } })
  }

  if (!product) {
    return null 
  }

  const expediteur = product.expediteur || 'undefined' 

  return (
<div className='w-60 hover:cursor-pointer border border-slate-300 rounded overflow-hidden shadow-lg mb-4 transition-transform duration-300 hover:scale-90 bg-slate-300	' onClick={handleClick}>
  <div className='w-full h-60'>
    <img
      alt={product.name || ''}
      src={product.image}
      className='object-cover w-full h-full transition-transform duration-500 ease-in-out hover:shadow-lg hover:scale-105'
    />
  </div>
  <div className='p-4'>
  <p className='mt-2 text-lg text-gray-900 font-bold tracking-wide uppercase'>{product.name}</p>

    <div className='flex justify-between mt-2'>
      <p className='text-gray-700 font-medium'>{product.price}dt</p>
      <p className='text-gray-700 uppercase'>{product.categorie}</p>
    </div>
  </div>
</div>

  
  )
}
