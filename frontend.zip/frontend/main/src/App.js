import React from 'react'
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from 'react-router-dom'
import Homepage from './Pages/Homepage'
import Storespage from './Pages/Storespage'
import Singlestorepage from './Pages/Singlestorepage'
import Singleproductpage from './Pages/Singleproductpage'
import Register from './Components/Register'
import Login from './Components/Login'
import Panierpage from './Pages/Panierpage'
import Paimentpage from './Pages/Paimentpage'
import ResponsableStore from './Pages/ResponsabePages/ResponsableStore'
import AddProductForm from './Components/ResponsableComponents/AddProductForm'
import ResponsableDashboard from './Pages/ResponsabePages/ResponsableDashboard'
import Header from './Components/Header'
import Footer from './Components/Footer'
import { UserProvider } from './Usercontext'
import { useState, useEffect } from 'react'
import UserRoleDashboard from './Pages/UserRoleDashboard'
import AdminDashboard from './Pages/AdminDashmoard'
import ProfileDetails from './Components/ResponsableComponents/ProfileDetails'
import Productspage from './Pages/Productspage'
import Unauthorized from './Pages/Unauthorized'

function RoutesWrapper({ user }) {
  const location = useLocation()
  const shouldRenderHeader = !['/register', '/login'].includes(
    location.pathname,
  )

  return (
    <>
      {shouldRenderHeader && <Header />}
      <Routes>
        <Route path='/' element={<Homepage />} />
        <Route path='/home' element={<Homepage />} />
        <Route path='/stores' element={<Storespage />} />
        <Route path='/store/:boutiqueId' element={<Singlestorepage />} />
        <Route path='/singleproduct' element={<Singleproductpage />} />
        <Route path='/panier' element={<Panierpage />} />
        <Route path='/paiment' element={<Paimentpage />} />
        <Route path='/register' element={<Register />} />
        <Route path='/login' element={<Login />} />
        <Route path='/products' element={<Productspage />} />
        <Route path='/unauthorized' element={<Unauthorized />} />

        {user && (
          <>
            <Route path='/mystore' element={<ResponsableStore />} />
            <Route path='/profile' element={<ProfileDetails />} />
            <Route path='/productadd' element={<AddProductForm />} />
            <Route
              path='/responsabledashboard'
              element={<ResponsableDashboard />}
            />
            <Route path='/admin-dashboard' element={<AdminDashboard />} />
            {user.role === 'Admin' && (
              <Route path='/admin/userRoles' element={<UserRoleDashboard />} />
            )}
          </>
        )}
      </Routes>
    </>
  )
}

function App() {
  const [user, setUser] = useState(localStorage.getItem('userData'))

  useEffect(() => {
    // Update user state when localStorage changes
    const handleStorageChange = () => {
      setUser(localStorage.getItem('userData'))
    }
    window.addEventListener('storage', handleStorageChange)
    return () => {
      window.removeEventListener('storage', handleStorageChange)
    }
  }, [])

  return (
    <UserProvider value={{ user, setUser }}>
      <div className='App'>
        <Router>
          <RoutesWrapper user={user} />
          <Footer />
        </Router>
      </div>
    </UserProvider>
  )
}

export default App
