import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const ResponsableDashboard = () => {
  const [activeTab, setActiveTab] = useState('store')
  const [store, setStore] = useState(null)
  const [articles, setArticles] = useState([])
  const [boutiqueid, setBoutiqueid] = useState(null)
  const [storeData, setStoreData] = useState({
    name: '',
    email: '',
    telephone: '',
    imageUrl:''
  })
  const [articleData, setArticleData] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    categorie: '',
    image: '',
  })
  const [editingArticleId, setEditingArticleId] = useState(null)
   const navigate = useNavigate()

   useEffect(() => {
     checkUserRole()
   }, [])

   const checkUserRole = async () => {
     try {
       const userData = JSON.parse(localStorage.getItem('userData'))
       if (userData && userData.role === 'Responsable') {
         fetchStore()
         fetchArticles()
       } else {
         navigate('/unauthorized')
       }
     } catch (error) {
       console.error('Error checking user role:', error)
       navigate('/unauthorized')
     }
   }
   const fetchStore = async () => {
     try {
       const userData = JSON.parse(localStorage.getItem('userData'))
       if (!userData || !userData._id) {
         console.error('Invalid userData or user ID')
         return
       }
       const userResponse = await axios.get(
         `http://localhost:3000/user/getUser/${userData._id}`,
         {
           headers: {
             Authorization: `Bearer ${localStorage.getItem('token')}`,
           },
         },
       )
       const user = userResponse.data
       setBoutiqueid(user.boutiqueId)

       if (!user.boutiqueId) {
         console.error('User does not have a boutiqueId')
         return
       }

       const storeResponse = await axios.get(
         `http://localhost:3000/userRole/getBoutique/${user.boutiqueId}`,
         {
           headers: {
             Authorization: `Bearer ${localStorage.getItem('token')}`,
           },
         },
       )
       setStore(storeResponse.data)
       setStoreData(storeResponse.data)
     } catch (error) {
       console.error('Error fetching store:', error)
     }
   }
   const fetchArticles = async () => {
     try {
       const userData = JSON.parse(localStorage.getItem('userData'))
       if (!userData || !userData._id) {
         console.error('Invalid userData or user ID')
         return
       }
       const userResponse = await axios.get(
         `http://localhost:3000/user/getUser/${userData._id}`,
         {
           headers: {
             Authorization: `Bearer ${localStorage.getItem('token')}`,
           },
         },
       )
       const user = userResponse.data

       if (!user.boutiqueId) {
         console.error('User does not have a boutiqueId')
         return
       }

       const articlesResponse = await axios.get(
         `http://localhost:3000/userRole/getArticleBoutique/${user.boutiqueId}`,
         {
           headers: {
             Authorization: `Bearer ${localStorage.getItem('token')}`,
           },
         },
       )
       setArticles(articlesResponse.data)
     } catch (error) {
       console.error('Error fetching articles:', error)
     }
   }
   fetchStore()
   fetchArticles()


  const handleTabChange = (tab) => {
    setActiveTab(tab)
  }

  const handleStoreUpdate = async () => {
    try {
      await axios.put(
        `http://localhost:3000/userRole/updateBoutique/${store._id}`,
        storeData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      // Refresh store after update
      const response = await axios.get(
        `http://localhost:3000/userRole/getBoutique/${store._id}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      setStore(response.data)
    } catch (error) {
      console.error('Error updating store:', error)
    }
  }
  const handleArticleSubmit = async (e) => {
    e.preventDefault()
    try {
      const userData = JSON.parse(localStorage.getItem('userData'))
      if (!userData || !userData._id) {
        console.error('Invalid userData or user ID')
        return
      }
      const userResponse = await axios.get(
        `http://localhost:3000/user/getUser/${userData._id}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      const user = userResponse.data

      if (!user.boutiqueId) {
        console.error('User does not have a boutiqueId')
        return
      }

      const articleDataWithExpeditor = {
        ...articleData,
        expediteur: user.boutiqueId,
      }
      await axios.post(
        'http://localhost:3000/userRole/addArticle',
        articleDataWithExpeditor,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      // Refresh articles after adding a new one
      const articlesResponse = await axios.get(
        `http://localhost:3000/userRole/getArticleBoutique/${user.boutiqueId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      setArticles(articlesResponse.data)
      setArticleData({
        name: '',
        description: '',
        price: '',
        stock: '',
        categorie: '',
        image: '',
      })
    } catch (error) {
      console.error('Error adding article:', error)
    }
  }

  const handleArticleUpdate = (articleId) => {
    setEditingArticleId(articleId)
    const article = articles.find((article) => article._id === articleId)
    if (article) {
      setArticleData({
        name: article.name,
        description: article.description,
        price: article.price,
        stock: article.stock,
        categorie: article.categorie,
        image: article.image,
      })
    }
  }
  const handleSaveChanges = async () => {
    try {
      const userData = JSON.parse(localStorage.getItem('userData'))
      if (!userData || !userData._id) {
        console.error('Invalid userData or user ID')
        return
      }
      const userResponse = await axios.get(
        `http://localhost:3000/user/getUser/${userData._id}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      const user = userResponse.data

      if (!user.boutiqueId) {
        console.error('User does not have a boutiqueId')
        return
      }

      const updatedArticleData = {
        ...articleData,
        expediteur: user.boutiqueId,
      }

      await axios.put(
        `http://localhost:3000/userRole/updateArticle/${editingArticleId}`,
        updatedArticleData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )

      // Refresh articles after update
      const response = await axios.get(
        `http://localhost:3000/userRole/getArticleBoutique/${user.boutiqueId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      setArticles(response.data)
      setEditingArticleId(null)
      setArticleData({
        name: '',
        description: '',
        price: '',
        stock: '',
        categorie: '',
        image: '',
      })
    } catch (error) {
      console.error('Error updating article:', error)
    }
  }
  const handleArticleDelete = async (articleId) => {
    try {
      await axios.delete(
        `http://localhost:3000/userRole/deleteArticle/${articleId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      // Refresh articles after delete
      const userData = JSON.parse(localStorage.getItem('userData'))
      const response = await axios.get(
        `http://localhost:3000/userRole/getArticleBoutique/${userData.boutiqueId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        },
      )
      setArticles(response.data)
    } catch (error) {
      console.error('Error deleting article:', error)
    }
  }

  return (
    <div className='min-h-screen bg-gray-100'>
      <header className='bg-white shadow'>
        <div className='max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8'>
          <h1 className='text-3xl font-bold leading-tight text-gray-900'>
            Responsable Dashboard
          </h1>
        </div>
      </header>
      <main>
        <div className='max-w-7xl mx-auto py-6 sm:px-6 lg:px-8'>
          <div className='px-4 py-6 sm:px-0'>
            <div className='flex justify-center mb-4'>
              <button
                className={`px-4 py-2 rounded-l ${
                  activeTab === 'store'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700'
                }`}
                onClick={() => handleTabChange('store')}
              >
                Store
              </button>
              <button
                className={`px-4 py-2 rounded-r ${
                  activeTab === 'articles'
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700'
                }`}
                onClick={() => handleTabChange('articles')}
              >
                Articles
              </button>
            </div>
            {activeTab === 'store' && store && (
              <div className='bg-white shadow overflow-hidden sm:rounded-lg'>
                <div className='px-4 py-5 sm:px-6'>
                  <h3 className='text-lg leading-6 font-medium text-gray-900'>
                    Store Details
                  </h3>
                  <div className='mt-4'>
                    <label
                      htmlFor='name'
                      className='block text-sm font-medium text-gray-700'
                    >
                      Name
                    </label>
                    <input
                      type='text'
                      name='name'
                      id='name'
                      value={storeData.name}
                      onChange={(e) =>
                        setStoreData({ ...storeData, name: e.target.value })
                      }
                      className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                    />
                  </div>
                  <div className='mt-4'>
                    <label
                      htmlFor='email'
                      className='block text-sm font-medium text-gray-700'
                    >
                      Email
                    </label>
                    <input
                      type='email'
                      name='email'
                      id='email'
                      value={storeData.email}
                      onChange={(e) =>
                        setStoreData({ ...storeData, email: e.target.value })
                      }
                      className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                    />
                  </div>
                  <div className='mt-4'>
                    <label
                      htmlFor='telephone'
                      className='block text-sm font-medium text-gray-700'
                    >
                      Telephone
                    </label>
                    <input
                      type='tel'
                      name='telephone'
                      id='telephone'
                      value={storeData.telephone}
                      onChange={(e) =>
                        setStoreData({
                          ...storeData,
                          telephone: e.target.value,
                        })
                      }
                      className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                    />
                  </div>
                  <div className='mt-4'>
                    <label
                      htmlFor='imageUrl'
                      className='block text-sm font-medium text-gray-700'
                    >
                      Image URL
                    </label>
                    <input
                      type='text'
                      name='imageUrl'
                      id='imageUrl'
                      value={storeData.imageUrl}
                      onChange={(e) =>
                        setStoreData({ ...storeData, imageUrl: e.target.value })
                      }
                      className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                    />
                  </div>
                  <button
                    className='mt-4 px-4 py-2 bg-blue-500 text-white rounded'
                    onClick={handleStoreUpdate}
                  >
                    Update Store
                  </button>
                </div>
              </div>
            )}
            {activeTab === 'articles' && (
              <div>
                <h3 className='text-lg leading-6 font-medium text-gray-900'>
                  Articles
                </h3>
                <div className='mt-4'>
                  <form onSubmit={handleArticleSubmit}>
                    <div className='grid grid-cols-2 gap-4'>
                      <div>
                        <label
                          htmlFor='name'
                          className='block text-sm font-medium text-gray-700'
                        >
                          Name
                        </label>
                        <input
                          type='text'
                          name='name'
                          id='name'
                          value={articleData.name}
                          onChange={(e) =>
                            setArticleData({
                              ...articleData,
                              name: e.target.value,
                            })
                          }
                          className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                          required
                        />
                      </div>
                      <div>
                        <label
                          htmlFor='description'
                          className='block text-sm font-medium text-gray-700'
                        >
                          Description
                        </label>
                        <input
                          type='text'
                          name='description'
                          id='description'
                          value={articleData.description}
                          onChange={(e) =>
                            setArticleData({
                              ...articleData,
                              description: e.target.value,
                            })
                          }
                          className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                          required
                        />
                      </div>
                      <div>
                        <label
                          htmlFor='price'
                          className='block text-sm font-medium text-gray-700'
                        >
                          Price
                        </label>
                        <input
                          type='text'
                          name='price'
                          id='price'
                          value={articleData.price}
                          onChange={(e) =>
                            setArticleData({
                              ...articleData,
                              price: e.target.value,
                            })
                          }
                          className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                          required
                        />
                      </div>
                      <div>
                        <label
                          htmlFor='stock'
                          className='block text-sm font-medium text-gray-700'
                        >
                          Stock
                        </label>
                        <input
                          type='text'
                          name='stock'
                          id='stock'
                          value={articleData.stock}
                          onChange={(e) =>
                            setArticleData({
                              ...articleData,
                              stock: e.target.value,
                            })
                          }
                          className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                          required
                        />
                      </div>
                      <div>
                        <label
                          htmlFor='categorie'
                          className='block text-sm font-medium text-gray-700'
                        >
                          Categorie
                        </label>
                        <input
                          type='text'
                          name='categorie'
                          id='categorie'
                          value={articleData.categorie}
                          onChange={(e) =>
                            setArticleData({
                              ...articleData,
                              categorie: e.target.value,
                            })
                          }
                          className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                          required
                        />
                      </div>
                      <div>
                        <label
                          htmlFor='image'
                          className='block text-sm font-medium text-gray-700'
                        >
                          Image URL
                        </label>
                        <input
                          type='text'
                          name='image'
                          id='image'
                          value={articleData.image}
                          onChange={(e) =>
                            setArticleData({
                              ...articleData,
                              image: e.target.value,
                            })
                          }
                          className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                          required
                        />
                      </div>
                    </div>
                    <button
                      type='submit'
                      className='mt-4 px-4 py-2 bg-blue-500 text-white rounded'
                    >
                      Add Article
                    </button>
                  </form>
                </div>
                <div className='mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3'>
                  {articles.map((article) => (
                    <div
                      key={article._id}
                      className='bg-white shadow overflow-hidden sm:rounded-lg'
                    >
                      <div className='px-4 py-5 sm:px-6'>
                        {editingArticleId === article._id ? (
                          <>
                            <input
                              type='text'
                              name='name'
                              value={articleData.name}
                              onChange={(e) =>
                                setArticleData({
                                  ...articleData,
                                  name: e.target.value,
                                })
                              }
                              className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                            />
                            <input
                              type='text'
                              name='description'
                              value={articleData.description}
                              onChange={(e) =>
                                setArticleData({
                                  ...articleData,
                                  description: e.target.value,
                                })
                              }
                              className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                            />
                            <input
                              type='text'
                              name='price'
                              value={articleData.price}
                              onChange={(e) =>
                                setArticleData({
                                  ...articleData,
                                  price: e.target.value,
                                })
                              }
                              className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                            />
                            <input
                              type='text'
                              name='stock'
                              value={articleData.stock}
                              onChange={(e) =>
                                setArticleData({
                                  ...articleData,
                                  stock: e.target.value,
                                })
                              }
                              className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                            />
                            <input
                              type='text'
                              name='categorie'
                              value={articleData.categorie}
                              onChange={(e) =>
                                setArticleData({
                                  ...articleData,
                                  categorie: e.target.value,
                                })
                              }
                              className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                            />
                            <input
                              type='text'
                              name='image'
                              value={articleData.image}
                              onChange={(e) =>
                                setArticleData({
                                  ...articleData,
                                  image: e.target.value,
                                })
                              }
                              className='mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md'
                            />
                            <button
                              className='mt-4 px-4 py-2 bg-blue-500 text-white rounded'
                              onClick={handleSaveChanges}
                            >
                              Save Changes
                            </button>
                          </>
                        ) : (
                          <>
                            <h3 className='text-lg leading-6 font-medium text-gray-900'>
                              {article.name}
                            </h3>
                            <p className='mt-1 max-w-2xl text-sm text-gray-500'>
                              {article.description}
                            </p>
                            <p className='mt-1 max-w-2xl text-sm text-gray-500'>
                              Price: {article.price}
                            </p>
                            <p className='mt-1 max-w-2xl text-sm text-gray-500'>
                              Stock: {article.stock}
                            </p>
                            <p className='mt-1 max-w-2xl text-sm text-gray-500'>
                              Categorie: {article.categorie}
                            </p>
                            <img
                              src={article.image}
                              alt={article.name}
                              className='mt-4 w-full h-40 object-cover'
                            />
                            <div className='mt-4'>
                              <button
                                className='px-4 py-2 bg-blue-500 text-white rounded mr-2'
                                onClick={() => handleArticleUpdate(article._id)}
                              >
                                Update Article
                              </button>
                              <button
                                className='px-4 py-2 bg-red-500 text-white rounded'
                                onClick={() => handleArticleDelete(article._id)}
                              >
                                Delete Article
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

export default ResponsableDashboard
