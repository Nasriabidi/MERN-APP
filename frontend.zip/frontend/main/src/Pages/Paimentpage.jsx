import React, { useState } from 'react'
import { useLocation } from 'react-router-dom'
import Header from '../Components/Header'
import axios from 'axios'

function Paimentpage() {
  const location = useLocation()
  const { cartItems, totalPrice } = location.state || {}
  const [formData, setFormData] = useState({
    email: '',
    country: '',
    firstName: '',
    lastName: '',
    address: '',
    postalCode: '',
    city: '',
    telephone: '',
  })
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [orderConfirmed, setOrderConfirmed] = useState(false)

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setShowConfirmation(true)
  }

  const handleConfirmOrder = async () => {
    const userData = JSON.parse(localStorage.getItem('userData'))
    const userId = userData._id
    try {
      const orderData = {
        userId: userId,
        email: formData.email,
        country: formData.country,
        firstName: formData.firstName,
        lastName: formData.lastName,
        address: formData.address,
        postalCode: formData.postalCode,
        city: formData.city,
        telephone: formData.telephone,
        cartItems: cartItems,
        totalPrice: totalPrice,
      }

      await axios.post('http://localhost:3000/api/orders', orderData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      localStorage.removeItem('cartItems')
      setOrderConfirmed(true)
    } catch (error) {
      console.error('Failed to create order:', error)
      // Handle error, e.g., show an error message to the user
    }
  }
  if (orderConfirmed) {
    return (
      <div className='flex justify-center mt-8 min-h-screen items-center'>
        <div className='text-2xl font-semibold'>
          Thank you for your order! Your order has been successfully placed.
        </div>
      </div>
    )
  }

  return (
    <div>
      <div className='flex justify-center min-h-screen items-center mx-56 mt-4'>
        <form onSubmit={handleSubmit}>
          <div className='mt-4'>
            <div className='text-xl font-semibold'>Contact</div>
            <input
              type='text'
              name='email'
              required
              placeholder='Email ou numero de portable'
              value={formData.email}
              onChange={handleInputChange}
              className='mt-2 border border-2 rounded border-gray-500 h-12 w-[62vh] p-4'
            ></input>
            <div className='mt-4 text-xl font-semibold'>Livraison</div>
            <input
              type='text'
              name='country'
              required
              placeholder='Pays/Region'
              value={formData.country}
              onChange={handleInputChange}
              className='mt-2 border border-2 rounded border-gray-500 h-12 w-[62vh] p-4'
            ></input>
            <div className='grid grid-cols-2 gap-4 mt-4'>
              <div>
                <input
                  type='text'
                  name='firstName'
                  required
                  placeholder='Prenom'
                  value={formData.firstName}
                  onChange={handleInputChange}
                  className='mt-2 border border-2 rounded border-gray-500 h-12 w-[30vh] p-4'
                ></input>
              </div>
              <div>
                <input
                  type='text'
                  name='lastName'
                  required
                  placeholder='Nom'
                  value={formData.lastName}
                  onChange={handleInputChange}
                  className='mt-2 border border-2 rounded border-gray-500 h-12 w-[30vh] p-4'
                ></input>
              </div>
            </div>
            <div className='flex flex-col'>
              <input
                type='text'
                name='address'
                required
                placeholder='Adresse'
                value={formData.address}
                onChange={handleInputChange}
                className='mt-2 border border-2 rounded border-gray-500 h-12 w-[62vh] p-4'
              ></input>
              <div className='grid grid-cols-2 gap-4 mt-4'>
                <input
                  type='number'
                  name='postalCode'
                  required
                  placeholder='Code postal'
                  value={formData.postalCode}
                  onChange={handleInputChange}
                  className='mt-2 border border-2 rounded border-gray-500 h-12 w-[30vh] p-4'
                ></input>
                <input
                  type='text'
                  name='city'
                  required
                  placeholder='Ville'
                  value={formData.city}
                  onChange={handleInputChange}
                  className='mt-2 border border-2 rounded border-gray-500 h-12 w-[30vh] p-4'
                ></input>
              </div>
              <input
                type='number'
                name='telephone'
                required
                placeholder='Telephone'
                value={formData.telephone}
                onChange={handleInputChange}
                className='mt-4 border border-2 rounded border-gray-500 h-12 w-[62vh] p-4'
              ></input>
              <button
                type='submit'
                className='mt-4 border border-2 rounded-md h-16 w-[62vh] p-4 bg-indigo-600 hover:bg-indigo-700 text-xl font-semibold text-white'
              >
                Valider le paiment
              </button>
            </div>
          </div>
        </form>
        <div className=''></div>
      </div>
      {showConfirmation && (
        <div className='fixed inset-0 flex items-center justify-center w-[screen] bg-black bg-opacity-50 z-50'>
          <div className='bg-white p-8 rounded w-1/4 shadow-lg'>
            <h2 className='text-2xl font-semibold mb-4'>Confirm Order</h2>
            <div className='mb-4'>
              <h3 className='text-lg font-semibold'>Cart Items:</h3>
              <ul>
                {cartItems.map((item, index) => (
                  <li key={index}>
                    {item.product.name} - Quantity: {item.quantity}
                  </li>
                ))}
              </ul>
              <p className='mt-2'>Total Price: {totalPrice.toFixed(2)} DT</p>
            </div>
            <div className='mb-4'>
              <h3 className='text-lg font-semibold'>Delivery Details:</h3>
              <p>Email: {formData.email}</p>
              <p>Country: {formData.country}</p>
              <p>First Name: {formData.firstName}</p>
              <p>Last Name: {formData.lastName}</p>
              <p>Address: {formData.address}</p>
              <p>Postal Code: {formData.postalCode}</p>
              <p>City: {formData.city}</p>
              <p>Telephone: {formData.telephone}</p>
            </div>
            <div className='flex justify-end'>
              <button
                className='bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded mr-2'
                onClick={handleConfirmOrder}
              >
                Confirm
              </button>
              <button
                className='bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-4 rounded'
                onClick={() => setShowConfirmation(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Paimentpage
