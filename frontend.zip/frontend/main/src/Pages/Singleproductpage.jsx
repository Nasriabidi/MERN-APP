import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import Header from '../Components/Header'
import Productcard from '../Components/Productcard'
import OfferBarTop from '../Components/OfferBarTop'
import QuantityButtonComponent from '../Components/QuantityButtonComponent'

function Singleproductpage() {
  const navigate = useNavigate()
  const location = useLocation()
  const { product } = location.state || {}
  const [quantity, setQuantity] = useState(1)
  const [topProducts, setTopProducts] = useState([])
  const [isAdminOrResponsible, setIsAdminOrResponsible] = useState(false)

  const fetchTopProducts = async () => {
    try {
      const response = await fetch('http://localhost:3000/userRole/getArticle')
      const data = await response.json()
      const topFiveProducts = data.slice(0, 5) // Get the top 5 products
      setTopProducts(topFiveProducts)
    } catch (error) {
      console.error('Error fetching top products:', error)
    }
  }

  useEffect(() => {
    fetchTopProducts()
    const userDataString = localStorage.getItem('userData')
    if (userDataString) {
      const userData = JSON.parse(userDataString)
      const userRole = userData.role
      setIsAdminOrResponsible(
        userRole === 'Admin' || userRole === 'Responsible' ,
      )
    }
  }, [])

  const handleIncrement = () => {
    if (!isAdminOrResponsible) {
      setQuantity(quantity + 1)
    }
  }

  const handleDecrement = () => {
    if (!isAdminOrResponsible && quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  function addToCart() {
    if (!isAdminOrResponsible && quantity > 0) {
      const cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]')
      const existingItemIndex = cartItems.findIndex(
        (item) => item.product._id === product._id,
      )

      if (existingItemIndex !== -1) {
        cartItems[existingItemIndex].quantity += quantity
      } else {
        cartItems.push({ product, quantity })
      }

      localStorage.setItem('cartItems', JSON.stringify(cartItems))
      navigate('/panier')
    }
  }

  return (
    <div className='relative'>
      <div className='flex pt-8 px-60'>
        <div className='w-96 h-[60vh] mt-8 ml-16'>
          <img
            src={product?.image}
            className='object-cover w-full h-full'
            alt='Product'
          />
        </div>
        <div className='ml-16'>
          <h1 className='text-2xl font-bold'>{product?.name}</h1>
          <p className='mt-4 text-gray-600'>{product?.description}</p>
          <p className='mt-4 text-gray-600'>{product?.price} dt</p>

          <p className='mt-4 text-gray-600'>Quantité</p>
          {!isAdminOrResponsible && (
            <QuantityButtonComponent
              quantity={quantity}
              onIncrement={handleIncrement}
              onDecrement={handleDecrement}
            />
          )}
          {!isAdminOrResponsible ? (
            <button
              className='h-12 mt-4 text-white bg-black border border-black w-96 hover:scale-102 hover:shadow-md'
              onClick={addToCart}
            >
              Ajouter au panier
            </button>
          ) : (
            <p className='mt-4 text-red-500'>Admin and Responsible can't buy</p>
          )}
          <a href={`/store/${product.expediteur}`}>
            <button className='h-12 mt-4 border border-black w-96 hover:border-2'>
              Go back
            </button>
          </a>
        </div>
      </div>
      <div className='flex flex-col items-center justify-center mt-8'>
        <h4 className='text-3xl text-start text-gray-700'>Similar products</h4>
        <div className='grid grid-cols-5 mt-12 gap-4'>
          {topProducts.map((product, index) => (
            <Productcard key={index} product={product} />
          ))}
        </div>
      </div>
    </div>
  )
}

export default Singleproductpage