import React from 'react'
import { Link } from 'react-router-dom'

export default function Unauthorized() {
  return (
    <div className='h-screen bg-black text-white text-center flex items-center flex-col justify-center'>
      <h1 className='text-7xl mb-6'>Unauthorized</h1>
      <Link to='/' className='bg-white p-2 text-black'>Go to home page</Link>
    </div>
  )
}
