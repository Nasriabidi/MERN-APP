import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PanierProduct from '../Components/PanierProduct';

function Panierpage() {
  const [cartItems, setCartItems] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const storedCartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    setCartItems(storedCartItems);
    const totalPrice = storedCartItems.reduce(
      (total, item) => total + item.product.price * item.quantity,
      0
    );
    setTotalPrice(totalPrice);
  }, []);

  const handleQuantityChange = (productId, newQuantity) => {
    const updatedCartItems = cartItems.map((item) => {
      if (item.product._id === productId) {
        return { ...item, quantity: newQuantity };
      }
      return item;
    });
    setCartItems(updatedCartItems);
    localStorage.setItem('cartItems', JSON.stringify(updatedCartItems));
    const updatedTotalPrice = updatedCartItems.reduce(
      (total, item) => total + item.product.price * item.quantity,
      0
    );
    setTotalPrice(updatedTotalPrice);
  };

  const handleRemoveProduct = (productId) => {
    const updatedCartItems = cartItems.filter(
      (item) => item.product._id !== productId
    );
    setCartItems(updatedCartItems);
    localStorage.setItem('cartItems', JSON.stringify(updatedCartItems));
    const updatedTotalPrice = updatedCartItems.reduce(
      (total, item) => total + item.product.price * item.quantity,
      0
    );
    setTotalPrice(updatedTotalPrice);
  };

  const handleProceedToPayment = () => {
    navigate('/paiment', { state: { cartItems, totalPrice } });
  };

  return (
    <div className='min-h-screen'>
      <div className='flex justify-between mx-56 mt-20'>
        <h1 className='text-4xl bold'>Votre panier</h1>
        <p className='text-gray-500 underline'>
          <a href='/stores'>Continuer les achats</a>
        </p>
      </div>
      <div className='grid grid-cols-4 mx-56 mt-8 text-sm text-gray-400'>
        <div>Produit</div>
        <div></div>
        <div>Quantité</div>
        <div className='text-right'>Total</div>
      </div>
      <hr className='mx-56 mt-4' />
      <div className='mx-56 mt-4'>
        {cartItems.map((item, index) => (
          <PanierProduct
            key={index}
            product={item.product}
            quantity={item.quantity}
            onQuantityChange={handleQuantityChange}
            onRemoveProduct={handleRemoveProduct}
          />
        ))}
      </div>

      <div className='flex flex-col float-right mx-56 mt-12'>
        <div className='flex flex-row justify-end gap-4'>
          <div>Total estimé</div>
          <div>{totalPrice.toFixed(2)} DT</div>
        </div>
        <div>
          <button
            className='h-12 mt-8 text-white bg-black border border-black w-96 hover:scale-102 hover:shadow-md'
            onClick={handleProceedToPayment}
          >
            Proceder au paiment
          </button>
        </div>
      </div>
    </div>
  )
}

export default Panierpage;