import React, { useState, useEffect } from 'react'
import axios from 'axios'
import boutique from '../Assets/boutique.jpg'
import arrow from '../Assets/next.png'
import { useNavigate } from 'react-router-dom'

function Storespage() {
  const [data, setData] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchStoreData()
  }, [])

  const fetchStoreData = async () => {
    try {
      const response = await axios.get(
        'http://localhost:3000/userRole/getBoutique',
      )
      setData(response.data)
      setIsLoading(false)
    } catch (error) {
      console.error('Error fetching store data:', error)
      setIsLoading(false)
    }
  }

  return (
    <div className='pt-8 px-60'>
      <h1 className='text-4xl mb-8'>Boutiques</h1>
      {isLoading ? (
        <p>Loading...</p>
      ) : (
        <div className='grid grid-cols-4 gap-8'>
          {data.map((store) => (
            <Storecard key={store._id} store={store} />
          ))}
        </div>
      )}
    </div>
  )
}

export default Storespage

function Storecard({ store }) {
  const navigate = useNavigate()

  const handleClick = () => {
    navigate(`/store/${store._id}`)
  }

  return (
    <div
      className='bg-white border border-gray-200 border-slate-300 shadow dark:bg-gray-800 dark:border-gray-700 mb-4 transition-transform duration-300 hover:scale-90 rounded-lg overflow-hidden cursor-pointer'
      onClick={handleClick}
    >
      <img
        className='w-full h-48 object-cover'
        src={store.imageUrl || boutique}
        alt={store.name}
      />
      <div className='p-4 bg-gray-200 dark:bg-gray-700 flex items-center justify-between'>
        <h2 className='text-xl font-bold tracking-tight text-gray-900 dark:text-white'>
          {store.name}
        </h2>
        <img src={arrow} className='w-4 ml-2' alt='Arrow' />
      </div>
    </div>
  )
}
