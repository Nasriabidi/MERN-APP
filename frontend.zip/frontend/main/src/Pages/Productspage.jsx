import { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import Productcard from '../Components/Productcard'

export default function Productspage() {
  const [products, setProducts] = useState([])
  const [searchParams] = useSearchParams() // Get search query parameters
  const searchQuery = searchParams.get('search') || '' // Get the search query parameter

  useEffect(() => {
    fetchProducts()
  }, [searchQuery]) // Add searchQuery as a dependency

  const fetchProducts = async () => {
    try {
      const response = await fetch('http://localhost:3000/userRole/getArticle')
      const data = await response.json()
      const filteredProducts = searchQuery
        ? data.filter((product) =>
            product.name.toLowerCase().includes(searchQuery.toLowerCase()),
          )
        : data
      setProducts(filteredProducts)
    } catch (error) {
      console.error('Error fetching products:', error)
    }
  }

  return (
    <div className='flex gap-5 flex-wrap justify-center '>
      {products.map((product, index) => (
        <Productcard key={index} product={product} />
      ))}
    </div>
  )
}
