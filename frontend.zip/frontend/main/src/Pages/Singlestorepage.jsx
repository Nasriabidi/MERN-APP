import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import Header from '../Components/Header'
import Productcard from '../Components/Productcard'

function Singlestorepage() {
  const [data, setData] = useState([])
  const { boutiqueId } = useParams()

  useEffect(() => {
    fetchProducts()
  }, [boutiqueId])

  const fetchProducts = async () => {
    try {
      const response = await fetch(
        `http://localhost:3000/userRole/getArticleBoutique/${boutiqueId}`,
      )
      const data = await response.json()
      setData(data)
    } catch (error) {
      console.error('Error fetching products:', error)
    }
  }

  return (
    <div>
      <div className='pt-8 px-60 '>
        <h1 className='font-serif text-4xl font-semibold text-gray-700'>
          {data?.name}
        </h1>
        <h1 className='mt-12 text-4xl font-light text-gray-900'>Products</h1>
        <div className='grid grid-cols-3 gap-4'>
          {data.map((product) => (
            <Productcard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  )
}

export default Singlestorepage
