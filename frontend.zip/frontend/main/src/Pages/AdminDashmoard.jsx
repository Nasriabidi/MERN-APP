import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

export default function AdminDashboard() {
  const [users, setUsers] = useState([])
  const [boutiques, setBoutiques] = useState([])
  const [selectedUser, setSelectedUser] = useState(null)
  const [selectedBoutique, setSelectedBoutique] = useState(null)
  const [loading, setLoading] = useState(true)
  const [newBoutique, setNewBoutique] = useState({
    name: '',
    email: '',
    telephone: '',
    imageUrl: '',
  })
    const [orders, setOrders] = useState([])

    useEffect(() => {
      fetchOrders()
    }, [])
  const fetchOrders = async () => {
    try {
      const response = await axios.get('http://localhost:3000/api/orders', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      setOrders(response.data)
    } catch (error) {
      console.error('Error fetching orders:', error)
    }
  }
  const navigate = useNavigate()

  useEffect(() => {
    checkUserRole()
  }, [])

  const checkUserRole = async () => {
    try {
      const userData = JSON.parse(localStorage.getItem('userData'))
      if (userData && userData.role === 'Admin') {
        fetchUsers()
        fetchBoutiques()
        setLoading(false)
      } else {
        navigate('/unauthorized')
      }
    } catch (error) {
      console.error('Error checking user role:', error)
      navigate('/unauthorized')
    }
  }

  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:3000/user/getUser', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      setUsers(response.data)
    } catch (error) {
      alert(
        'Error performing the operation, please check your access with the admin',
      )
      console.error('Error fetching users:', error)
    }
  }

  const fetchBoutiques = async () => {
    try {
      const response = await axios.get(
        'http://localhost:3000/userRole/getBoutique',
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        },
      )
      setBoutiques(response.data)
    } catch (error) {
      alert(
        'Error performing the operation, please check your access with the admin',
      )
      console.error('Error fetching boutiques:', error)
    }
  }

  const updateUserRole = async (userId, role, boutiqueId) => {
    try {
      await axios.put(
        `http://localhost:3000/userRole/updateUserRole/${userId}`,
        { role, boutiqueId },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        },
      )
      fetchUsers()
      window.location.reload()
    } catch (error) {
      alert(
        'Error performing the operation, please check your access with the admin',
      )
      console.error('Error updating user role:', error)
    }
  }

  const deleteUserRole = async (userId) => {
    try {
      await axios.put(
        `http://localhost:3000/userRole/deleteUserRole/${userId}`,
        {},
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        },
      )
      fetchUsers()
    } catch (error) {
      alert(
        'Error performing the operation, please check your access with the admin',
      )
      console.error('Error deleting user role:', error)
    }
  }
const deleteUser = async (userId) => {
  try {
    await axios.delete(`http://localhost:3000/user/deleteUser/${userId}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    })
    alert("User deleted successfully")
    fetchUsers()
  } catch (error) {
    alert(
      'Error performing the operation, please check your access with the admin',
    )
    console.error('Error deleting user:', error)
  }
}
  const addBoutique = async (name, email, telephone, imageUrl) => {
    try {
      await axios.post(
        'http://localhost:3000/userRole/addBoutique',
        { name, email, telephone, imageUrl },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        },
      )
      fetchBoutiques()
      setSelectedBoutique(null) // Clear the selected boutique after adding
    } catch (error) {
      alert(
        'Error performing the operation, please check your access with the admin',
      )
      console.error('Error adding boutique:', error)
    }
  }
  const handleSubmit = async (e) => {
    e.preventDefault()

    if (
      !newBoutique.name ||
      !newBoutique.email ||
      !newBoutique.telephone ||
      !newBoutique.imageUrl
    ) {
      alert('Please fill in all the required fields')
      return
    }

    try {
      await axios.post(
        'http://localhost:3000/userRole/addBoutique',
        newBoutique,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        },
      )
      fetchBoutiques()
      setNewBoutique({
        name: '',
        email: '',
        telephone: '',
        imageUrl: '',
      })
    } catch (error) {
      alert(
        'Error performing the operation, please check your access with the admin',
      )
      console.error('Error adding boutique:', error)
    }
  }
  const deleteBoutique = async (boutiqueId) => {
    try {
      await axios.delete(
        `http://localhost:3000/userRole/deleteBoutique/${boutiqueId}`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        },
      )
      fetchBoutiques()
    } catch (error) {
      alert(
        'Error performing the operation, please check your access with the admin',
      )
      console.error('Error deleting boutique:', error)
    }
  }

  return (
    <div className='bg-gray-100 min-h-screen'>
      <div className='min-w-[100vw] mx-auto py-6 sm:px-6 lg:px-8'>
        <h2 className='text-3xl font-bold mb-4'>Admin Dashboard</h2>
        <div className='grid grid-cols-1 md:grid-cols-1 gap-8'>
          <div className='bg-white shadow-md rounded-lg p-6'>
            <h3 className='text-xl font-semibold mb-4'>Users</h3>
            <table className='w-full table-auto '>
              <thead className=''>
                <tr className='bg-gray-200 text-gray-600 uppercase text-sm leading-normal'>
                  <th className='py-3 px-6 text-left'>Name</th>
                  <th className='py-3 px-6 text-left'>Email</th>
                  <th className='py-3 px-6 text-left'>Role</th>
                  <th className='py-3 px-6 text-left'>Boutique</th>
                  <th className='py-3 px-6 text-center'>Actions</th>
                </tr>
              </thead>
              <tbody className='text-gray-600 text-sm font-light'>
                {users.map((user) => (
                  <tr
                    key={user._id}
                    className='border-b border-gray-200 hover:bg-gray-100'
                  >
                    <td className='py-3 px-6 text-left whitespace-nowrap'>
                      {user.name}
                    </td>
                    <td className='py-3 px-6 text-left'>{user.email}</td>
                    <td className='py-3 px-6 text-left'>{user.role}</td>
                    <td className='py-3 px-6 text-left'>
                      {user.role === 'Responsable'
                        ? boutiques.find(
                            (boutique) => boutique.responsableId === user._id,
                          )?.name || '-'
                        : '-'}
                    </td>
                    <td className='py-3 px-6 text-center'>
                      <button
                        className='bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mr-2'
                        onClick={() => setSelectedUser(user)}
                      >
                        Edit
                      </button>
                      <button
                        className='bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded'
                        onClick={() => deleteUser(user._id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {selectedUser && (
              <div className='mt-4'>
                <h4 className='text-lg font-semibold mb-2'>Edit User Role</h4>
                <div className='flex items-center mb-2'>
                  <select
                    className='border border-gray-300 rounded p-2 mr-2'
                    value={selectedUser.role}
                    onChange={(e) =>
                      setSelectedUser({ ...selectedUser, role: e.target.value })
                    }
                  >
                    <option value='User'>User</option>
                    <option value='Responsable'>Responsable</option>
                    <option value='Admin'>Admin</option>
                  </select>
                  {selectedUser.role === 'Responsable' && (
                    <select
                      className='border border-gray-300 rounded p-2'
                      value={selectedUser.boutiqueId}
                      onChange={(e) =>
                        setSelectedUser({
                          ...selectedUser,
                          boutiqueId: e.target.value,
                        })
                      }
                    >
                      <option value=''>Select Boutique</option>
                      {boutiques.map((boutique) => (
                        <option key={boutique._id} value={boutique._id}>
                          {boutique.name}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
                <div>
                  <button
                    className='bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded mr-2'
                    onClick={() =>
                      updateUserRole(
                        selectedUser._id,
                        selectedUser.role,
                        selectedUser.boutiqueId,
                      )
                    }
                  >
                    Save
                  </button>
                  <button
                    className='bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded'
                    onClick={() => setSelectedUser(null)}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
          <div className='bg-white shadow-md rounded-lg p-6'>
            <h3 className='text-xl font-semibold mb-4'>Boutiques</h3>
            <table className='w-full table-auto'>
              <thead>
                <tr className='bg-gray-200 text-gray-600 uppercase text-sm leading-normal'>
                  <th className='py-3 px-6 text-left'>Name</th>
                  <th className='py-3 px-6 text-left'>Email</th>
                  <th className='py-3 px-6 text-left'>Telephone</th>
                  <th className='py-3 px-6 text-left'>Image</th>
                  <th className='py-3 px-6 text-left'>Responsible</th>
                  <th className='py-3 px-6 text-center'>Actions</th>
                </tr>
              </thead>
              <tbody className='text-gray-600 text-sm font-light'>
                {boutiques.map((boutique) => (
                  <tr
                    key={boutique._id}
                    className='border-b border-gray-200 hover:bg-gray-100'
                  >
                    <td className='py-3 px-6 text-left whitespace-nowrap'>
                      {boutique.name}
                    </td>
                    <td className='py-3 px-6 text-left'>{boutique.email}</td>
                    <td className='py-3 px-6 text-left'>
                      {boutique.telephone}
                    </td>
                    <td className='py-3 px-6 text-left'>
                      <img
                        src={boutique.imageUrl}
                        alt={boutique.name}
                        className='w-20 h-20 object-cover'
                      />
                    </td>
                    <td className='py-3 px-6 text-left'>
                      {users.find((user) => user.boutiqueId === boutique._id)
                        ?.name || '-'}
                    </td>
                    <td className='py-3 px-6 text-center'>
                      <button
                        className='bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded'
                        onClick={() => deleteBoutique(boutique._id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className='mt-4'>
              <h4 className='text-lg font-semibold mb-2'>Add Boutique</h4>
              <form
                onSubmit={handleSubmit}
                className='flex flex-col md:flex-row'
              >
                <input
                  type='text'
                  placeholder='Name'
                  required
                  className='border border-gray-300 rounded p-2 mb-2 md:mb-0 md:mr-2'
                  value={newBoutique.name}
                  onChange={(e) =>
                    setNewBoutique({ ...newBoutique, name: e.target.value })
                  }
                />
                <input
                  type='email'
                  placeholder='Email'
                  required
                  className='border border-gray-300 rounded p-2 mb-2 md:mb-0 md:mr-2'
                  value={newBoutique.email}
                  onChange={(e) =>
                    setNewBoutique({ ...newBoutique, email: e.target.value })
                  }
                />
                <input
                  type='text'
                  placeholder='Telephone'
                  required
                  className='border border-gray-300 rounded p-2 mb-2 md:mb-0 md:mr-2'
                  value={newBoutique.telephone}
                  onChange={(e) =>
                    setNewBoutique({
                      ...newBoutique,
                      telephone: e.target.value,
                    })
                  }
                />
                <input
                  type='text'
                  placeholder='Image URL'
                  required
                  className='border border-gray-300 rounded p-2 mb-2 md:mb-0 md:mr-2'
                  value={newBoutique.imageUrl}
                  onChange={(e) =>
                    setNewBoutique({ ...newBoutique, imageUrl: e.target.value })
                  }
                />
                <button
                  type='submit'
                  className='bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded'
                >
                  Add
                </button>
              </form>
            </div>
          </div>
        </div>
        <div className='bg-white shadow-md rounded-lg p-6 mt-10'>
          <h3 className='text-xl font-semibold mb-4'>Orders</h3>
          <table className='w-full table-auto'>
            <thead>
              <tr className='bg-gray-200 text-gray-600 uppercase text-sm leading-normal'>
                <th className='py-3 px-6 text-left'>Order ID</th>
                <th className='py-3 px-6 text-left'>Name</th>
                <th className='py-3 px-6 text-left'>Address</th>
                <th className='py-3 px-6 text-left'>Items</th>
                <th className='py-3 px-6 text-left'>Order Value</th>
              </tr>
            </thead>
            <tbody className='text-gray-600 text-sm font-light'>
              {orders.map((order) => (
                <tr
                  key={order._id}
                  className='border-b border-gray-200 hover:bg-gray-100'
                >
                  <td className='py-3 px-6 text-left whitespace-nowrap'>
                    #{order._id}
                  </td>
                  <td className='py-3 px-6 text-left'>
                    {order.firstName} {order.lastName}
                  </td>
                  <td className='py-3 px-6 text-left'>
                    {order.address}, {order.city}, {order.country},{' '}
                    {order.postalCode}
                  </td>
                  <td className='py-3 px-6 text-left'>
                    {order.cartItems.map((item) => (
                      <div key={item.product._id}>
                        {item.product.name}: {item.quantity}
                      </div>
                    ))}
                  </td>
                  <td className='py-3 px-6 text-left'>{order.totalPrice} DT</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
